sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller) {
        "use strict";

        return Controller.extend("com.mg.erp53.salesordercreation.controller.Detail", {
            onInit: function () {
                this.oOwnerComponent = this.getOwnerComponent();

                this.oRouter = this.oOwnerComponent.getRouter();
                this.oModel = this.oOwnerComponent.getModel("CreateSalesModel");

                this.oRouter.getRoute("Master").attachPatternMatched(this._onProductMatched, this);
                this.oRouter.getRoute("Detail").attachPatternMatched(this._onProductMatched, this);

            },

            _onProductMatched: function (oEvent) {
                this._product = oEvent.getParameter("arguments").product || this._product || "0";
                this.getView().bindElement({
                    path: "/ProductCollection/" + this._product,
                    model: "products"
                });
            },


            handleFullScreen: function () {
                //  var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/fullScreen");
                //  this.oRouter.navTo("Detail");
                // var oModel = this.getView().getModel("app");
                var bFullScreen = this.oModel.getProperty("/actionButtonsInfo/midColumn/fullScreen");
                this.oModel.setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
                if (!bFullScreen) {
                    // store current layout and go full screen
                    this.oModel.setProperty("/previousLayout", this.oModel.getProperty("/layout"));
                    this.oModel.setProperty("/layout", "MidColumnFullScreen");
                } else {
                    // reset to previous layout
                    this.oModel.setProperty("/layout", this.oModel.getProperty("/previousLayout"));
                }
            },

            handleExitFullScreen: function () {
                var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/exitFullScreen");
                this.oRouter.navTo("Detail");
            },

            handleClose: function () {
                //             var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/closeColumn");
                this.oModel.setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
                this.oRouter.navTo("Master", {}, true);
            },

            onExit: function () {
                this.oRouter.getRoute("Master").detachPatternMatched(this._onProductMatched, this);
                this.oRouter.getRoute("Detail").detachPatternMatched(this._onProductMatched, this);
            }
        });
    });
