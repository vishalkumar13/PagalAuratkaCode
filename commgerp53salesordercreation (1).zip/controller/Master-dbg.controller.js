sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    'sap/ui/model/Sorter',
    'sap/m/MessageBox',
    'sap/f/library'
], function (JSONModel, Controller, Filter, FilterOperator, Sorter, messageBox, fioriLibrary) {
    "use strict";

    return Controller.extend("com.mg.erp53.salesordercreation.controller.Master", {
        onInit: function () {
            this.oView = this.getView();
            this._bDescendingSort = false;
            this.oProductsTable = this.oView.byId("productsTable");
            this.oRouter = this.getOwnerComponent().getRouter();
        },

        onSearch: function (oEvent) {
            var oTableSearchState = [],
                sQuery = oEvent.getParameter("query");

            if (sQuery && sQuery.length > 0) {
                oTableSearchState = [new Filter("Name", FilterOperator.Contains, sQuery)];
            }

            this.oProductsTable.getBinding("items").filter(oTableSearchState, "Application");
        },

        onAdd: function () {
            messageBox.information("This functionality is not ready yet.", { title: "Aw, Snap!" });
        },

        onSort: function () {
            this._bDescendingSort = !this._bDescendingSort;
            var oBinding = this.oProductsTable.getBinding("items"),
                oSorter = new Sorter("Name", this._bDescendingSort);

            oBinding.sort(oSorter);
        },

        // onListItemPress: function () {
        //     var oFCL = this.oView.getParent().getParent();

        //     oFCL.setLayout(fioriLibrary.LayoutType.TwoColumnsMidExpanded);
        // },

        onListItemPress: function (oEvent) {
			var productPath = oEvent.getSource().getBindingContext("products").getPath(),
				product = productPath.split("/").slice(-1).pop(),
				oNextUIState;
			this.getOwnerComponent().getHelper().then(function (oHelper) {
				oNextUIState = oHelper.getNextUIState(1);
				this.oRouter.navTo("Detail", {
					layout: oNextUIState.layout,
					product: product
				});
			}.bind(this));
		},
        
        onOptionSelect: function (oEvent) {
            this.handleReset();
        },

        /**
            * Below function is called to clear the table and file uploader once selection changed
            */
        handleReset: function () {
            this.getView().byId("btnupload").setEnabled(false);
            this.getView().byId("fileUploader").setValue("");
            this.getView().byId("Table").setVisible(false);
        },

        handleCancel: function () {
            this.getView().byId("btnupload").setEnabled(false);
            this.getView().byId("fileUploader").setValue("");
            this.getView().byId("Table").setVisible(false);
            this.getView().byId("RBImperial").setSelected(true);
            this.getView().byId("RB1").setSelected(true);
        },

        /**
       * Below function is called on template/file download
       */
        onDowmloadTemplatePress: function () {

            var oModel = this.getOwnerComponent().getModel("CreateSalesModel");
            var serviceURL = oModel.sServiceUrl;

            var selectedOption = this.getView().byId("_IDRadiobtngrp").getSelectedButton().getText();
            var ImperialFlag;

            if (selectedOption === "Imperial") {
                ImperialFlag = "X";
            } else {
                ImperialFlag = "";
            }

            var selection = this.getView().byId("_IDRadiobtngrp1").getSelectedButton().getText().toUpperCase().replaceAll(' ', '_');
            var url = serviceURL + "/TempDwnldFromBESet(TemplateName='" + selection + "',ImperiallFlag='" + ImperialFlag + "')/$value";

            this.downloadtemplate(url);

        },

        /**
           * Below function is common for all download templates
           */
        downloadtemplate: function (url) {
            var oBusyDialog = new sap.m.BusyDialog();
            oBusyDialog.open();

            $.ajax({
                type: "GET",
                url: url,
                async: true,
                success: function (response, data) {
                    oBusyDialog.close();
                    sap.m.URLHelper.redirect(url, true);
                },
                error: function (data) {
                    oBusyDialog.close();
                }

            });
        },

          /**
            * Below function is called on selecting any file to upload
            */
           onFileSelection: function (oEvent) {
            if (this.getView().byId("fileUploader").getValue() !== "") {
                this.getView().byId("btnupload").setEnabled(true);
            } else {
                this.getView().byId("btnupload").setEnabled(false);
            }
            this.file = oEvent.getParameters("files").files[0];
        },

        /**
        * Below function gets called for uploading file
        */
        handleUploadPress: function () {
            var that = this;
            var fileUploadVal = this.getView().byId("fileUploader");
           // var file = fileUploadVal.getFocusDomRef().files[0]; //working code for 1.96 version fix
            var fileName = fileUploadVal.getValue();
            var selectedRB = this.getView().byId("_IDRadiobtngrp1").getSelectedButton().getText().toUpperCase().replaceAll(' ', '_');
            if (this.file) {

                this.oModel = this.getOwnerComponent().getModel("CreateSalesModel");
                var serviceURL = this.oModel.sServiceUrl;
                var msg = this.getView().getModel("i18n").getResourceBundle().getText("txtUploadMsg");
                this.oBusyDialog = new sap.m.BusyDialog();
                this.oBusyDialog.setText(msg);
                this.oBusyDialog.open();

                var oHeaders = {
                    sendXHR: true,
                    "slug": fileName + "|" + selectedRB,
                    "X-Requested-With": "XMLHttpRequest",
                    "Content-Type": "application/atom+xml",
                    "X-CSRF-Token": this.oModel.getSecurityToken()
                };

                var oURL = serviceURL + "/SalesOrderUploadSetSet";

                $.ajax({
                    type: "POST",
                    url: oURL,
                    headers: oHeaders,
                    cache: false,
                    dataType: "json",
                    contentType: 'application/json; charset=utf-8',
                    processData: false,
                    data: this.file,
                    success: function (response, data) {
                        that.oBusyDialog.close();
                        if (response && response.d.Status) {
                            messageBox.success(response.d.Status);
                            var StartCount = response.d.StartCount;
                            var EndCount = response.d.EndCount;
                            that.getUploadDetails(StartCount, EndCount);
                        }
                    },
                    error: function (oError) {
                        that.oBusyDialog.close();
                        if (oError && oError.responseJSON && oError.responseJSON.error && oError.responseJSON.error.message && oError.responseJSON.error.message.value) {
                            messageBox.error(oError.responseJSON.error.message.value);
                        }
                    }
                });
            }
        },

        /**
           * Below function is to get details to display table output for report to get status of uploaded file.
           */
        getUploadDetails: function (StartCount, EndCount) {
            this.oModel = this.getOwnerComponent().getModel("CreateSalesModel");
            var that = this;
            var oBusyDialog = new sap.m.BusyDialog();
            oBusyDialog.open();

            var filter = new sap.ui.model.Filter("StartCount", sap.ui.model.FilterOperator.EQ, StartCount);
            var filter1 = new sap.ui.model.Filter("EndCount", sap.ui.model.FilterOperator.EQ, EndCount);
            var filterMain = [];
            filterMain.push(filter);
            filterMain.push(filter1);

            var filterArray = [new sap.ui.model.Filter({
                filters: filterMain,
                and: true
            })];

            this.oModel.read("/MetsaHeaderDetailsSet", {
                filters: filterArray,
                urlParameters: {
                    "$expand": "OrderToItems"
                },
                success: function (oData, oResponse) {
                    debugger;
                    oBusyDialog.close();
                    if (oData.results.length > 0) {
                        var results = oData.results;
                       var sModel = new sap.ui.model.json.JSONModel(results);
                        sModel.setSizeLimit(oData.results.length);
                        that.getView().byId("Table").setVisible(true);
                        that.getView().setModel(sModel);
                    }
                },
                error: function (oError) {
                    oBusyDialog.close();
                }
            });
        },

        /**
         * Below function is called on file type mismatch check
         */
        handleTypeMissmatch: function (oEvent) {
            var oResourceModel = this.getView().getModel("i18n").getResourceBundle();
            var aFileTypes = oEvent.getSource().getFileType();
            aFileTypes.map(function (sType) {
                return "*." + sType;
            });
            var oStr = oResourceModel.getText("txtinitStr") + " " + oEvent.getParameter("fileType") + " " + oResourceModel.getText("txtlastStr") +
                aFileTypes.join(", ");
            sap.m.MessageToast.show(oStr);
            oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);

            const myTimeout = setTimeout(clearState, 3000);
            var that = this;
            function clearState() {
                that.byId("fileUploader").setValueState(sap.ui.core.ValueState.None);
            }
        }
    });
});
